<h1 align="center">🖥️Programação Orientada a Objetos</h1>

###

<h2 align="left">📡Tecnologias</h2>

###

<div align="left">
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg" height="40" alt="java logo"  />
  <img width="12" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/git/git-original.svg" height="40" alt="git logo"  />
  <img width="12" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/vscode/vscode-original.svg" height="40" alt="vscode logo"  />
</div>

###

<h2 align="left">🤝Colaboradores</h2>

###

<div align="left">
  <a href="https://github.com/ArthurNeiva017" target="_blank">
    <img src="https://img.shields.io/static/v1?message=Arthur%20NEIVA&logo=gitlab&label=&color=FF0000&logoColor=FF0000&labelColor=black&style=for-the-badge" height="39" alt="gitlab logo"  />
  </a>
</div>

###

<h2 align="left">🔥Status do GitHub</h2>

###

<div align="left">
  <img src="https://github-readme-stats.vercel.app/api/top-langs?username=ArthurNeiva017&locale=en&hide_title=false&layout=compact&card_width=320&langs_count=5&theme=gotham&hide_border=false&order=2" height="163" alt="languages graph"  />
</div>

###

<h2 align="left">📊Contribuições GitHub</h2>

###

<div align="left">
  <img src="https://github-readme-activity-graph.vercel.app/graph?username=ArthurNeiva017&radius=16&theme=gotham&area=true&order=5&hide_border=false" height="300" alt="activity-graph graph"  />
</div>

###
